#if_false.py 17Oct2024
if False:
    print("if False")
else:
    print("else: for if False")
    
