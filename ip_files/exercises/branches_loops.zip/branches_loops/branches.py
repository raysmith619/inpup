#branches.py    17Oct2024  crs
"""
Simple branches
"""
if 2 > 1:
    print("2>1")

if 1 > 2:
    print("1>2")
else:
    print("else: after if 1 > 2")


