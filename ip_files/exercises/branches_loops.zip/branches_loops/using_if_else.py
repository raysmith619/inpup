#using_if_else.py    17Oct2024  crs
"""
Testing if - else
"""
a = input("Enter a:")
b = input("Enter b:")
if a > b:
    print("a:",a,"is > b:",b)
else:
    print("a:",a,"IS NOT > b:",b)
    

