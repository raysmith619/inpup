#while_if_else_int.py    17Oct2024  crs
print("Testing while if - else on integers")
while True:
    a = int(input("Enter integer a:"))
    b = int(input("Enter integer b:"))
    if a > b:
        print("a:",a,"is > b:",b)
    else:
        print("a:",a,"IS NOT > b:",b)
    

