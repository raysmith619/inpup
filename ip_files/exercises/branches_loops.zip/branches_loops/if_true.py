#if_true.py 17Oct2024
if True:
    print("if True")
else:
    print("else: for if True")
    
