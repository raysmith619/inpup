#coin_flip_random_n.py  16Jun2025  crs
# List turns starting at 1
import random       #bring in support for randomization

# Let's use:
#   0 to represent fliping heads
#   1 to represent fliping tails

nflip = 5       # Number of flips

for n in range(1, nflip+1): # I like i starting from 0, n from 1 
    flip_result = random.randint(0,1)
    print(n, flip_result)        # Just to see something
    
