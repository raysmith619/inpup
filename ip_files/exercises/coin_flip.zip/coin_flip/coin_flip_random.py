#coin_flip_random.py  16Jun2025  crs, from coin_flip_loop.py
# Make it random
import random       #bring in support for randomization

# Let's use:
#   0 to represent fliping heads
#   1 to represent fliping tails

nflip = 5       # Number of flips

for i in range(nflip):
    flip_result = random.randint(0,1)
    print(i, flip_result)        # Just to see something
    
