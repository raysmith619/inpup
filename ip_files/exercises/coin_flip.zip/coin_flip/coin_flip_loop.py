#coin_flip_loop.py  16Jun2025  crs, Author
# Just to see something
nflip = 5       # Number of flips

for i in range(nflip):
    print(i)        # Just to see something
    
