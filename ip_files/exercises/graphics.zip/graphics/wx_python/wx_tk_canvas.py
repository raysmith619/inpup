# wx_tk_canvas.py 12Oct2023  crs, Author
"""
tkinter Canvas look-a-like for wxPython environment
Tarketed to code developed under tkinter but moving
to wxPython.
wx_class = WxTkCanvas()
"""
import wx
import tkinter as tk
