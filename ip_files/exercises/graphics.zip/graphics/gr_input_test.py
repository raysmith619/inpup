# gr_input_test.py   12Aug2021   crs, from gr_input.py
"""
Prompt User and accept input
"""
from gr_input import *  # Get all gr_input.py functions
"""
Testing Code
"""
inp = gr_input("Enter Number:")
print("We got:", inp)



