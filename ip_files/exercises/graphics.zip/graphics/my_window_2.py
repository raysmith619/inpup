#my_window_2.py   15Aug2021  crs, very simple

# The following imports all tkinter contents
from tkinter import *
root = Tk()
mainloop()






